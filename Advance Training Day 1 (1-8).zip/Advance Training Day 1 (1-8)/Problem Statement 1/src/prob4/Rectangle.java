package prob4;

public class Rectangle {
	private double length;
	private double breadth;
	
	
	
	public void setLength(double l) {
		
		if(length > 0) {
			length = l;
		}
		else {
			System.out.println("Invalid length: " + l);
		}
			
	}
	
	public double getLength() {
		return length;
	}
	
	public void setBreadth(double b) {
		if(breadth<20) {
			breadth = b;
		}
		else {
			System.out.println("Invalid breadth:"+ b);
		}
	}
	
	public double getBreadth() {
		return breadth;
	}
	
	
	public double getArea()
	   {
	      return length * breadth;
	   }
	public double getPerimeter()
	   {
	      return 2*(length + breadth);
	   }
		
	
	
	

}
