package prob4;

import prob4.Rectangle;

public class TestRectangle {

	public static void main(String[] args) {
Rectangle rect = new Rectangle();

	rect.setLength(8);
	rect.setBreadth(4);
		
		System.out.println("Area of Rectangle is "
                + rect.getArea());
		
		System.out.println("Preimeter of Rectangle is "
                + rect.getPerimeter());

	}

}
