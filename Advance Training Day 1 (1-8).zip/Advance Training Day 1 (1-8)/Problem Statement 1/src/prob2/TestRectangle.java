package prob2;

public class TestRectangle {

	public static void main(String[] args) {
		Rectangle rect = new Rectangle(4.5, 6.8);
		
		System.out.println("Area of Rectangle is "
                + rect.getArea());
	}

}
