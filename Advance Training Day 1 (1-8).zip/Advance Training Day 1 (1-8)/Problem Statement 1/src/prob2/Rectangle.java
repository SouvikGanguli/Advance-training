package prob2;

 class Rectangle {
	private double length;
	private double breadth;
	
	public Rectangle(double l, double b) 
	{
		length = l;
		breadth = b;
	}
	
	public void set(double l, double w)
	   {
	      length = l;
	      breadth  = w;
	   }
	public double getArea()
	   {
	      return length * breadth;
	   }
	
 }
 
	