package prob4;

import java.util.Scanner;
import java.util.Vector;
import java.util.jar.Attributes.Name;

public class PhoneBook {
	public static void main(String[]args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the choice:");
		System.out.println("\n1.Add new phone book entry \n2.Search Phone Number \n3.Quit");
		int choice = sc.nextInt();
		Vector v1 = new Vector();
		Vector<Name> v2 = new Vector<Name>();
		while(choice !=3) {
			 if(choice ==1) {
				 
				 System.out.println("enter the number of entry:");
				 int n = sc.nextInt();
				 for(int i = 0; i<=n; i++) {
					 v1.add(new Name(sc.next()));
				 }
			 }
			 System.out.println("enter the choice:");
			 System.out.println("\\n1.Add new phone book entry \\n2.Search Phone Number \\n3.Quit");
			 choice = sc.nextInt();
			 if(choice==2) {
				 System.out.println("number of entry:"+v1.size());
			 }
		}
		System.out.println("thank you");
	}
	
}

