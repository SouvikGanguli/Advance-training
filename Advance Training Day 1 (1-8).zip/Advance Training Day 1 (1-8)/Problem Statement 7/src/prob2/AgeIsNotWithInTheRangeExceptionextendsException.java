package prob2;

public class AgeIsNotWithInTheRangeExceptionextendsException {
	public String toString()
    {
         return ("Age is not between 15 and 21. please Retype the Age");
    }

}
