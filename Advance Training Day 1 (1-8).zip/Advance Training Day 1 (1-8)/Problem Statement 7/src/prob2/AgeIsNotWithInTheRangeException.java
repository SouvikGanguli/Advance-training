package prob2;

public class AgeIsNotWithInTheRangeException extends Exception{

}
