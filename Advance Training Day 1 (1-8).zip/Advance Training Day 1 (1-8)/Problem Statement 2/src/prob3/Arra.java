package prob3;

public class Arra {
	public static void main(String[] args) {      
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0}; 
		

