package prob2;

public class Seq {
	
		  public static void main(String[] args) {
			  for(int i=0; i<args.length; i++) {
				  System.out.println("args[" + i + "]: " +args[i]);
			  }

		    int n = 13, firstTerm = 1, secondTerm = 3;
		    System.out.println(n);

		    for (int i = 1; i <= n; ++i) {
		      System.out.print(firstTerm + ", ");

		      // compute the next term
		      int nextTerm = firstTerm + secondTerm;
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;
		    }

}
}